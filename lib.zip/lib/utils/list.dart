import 'package:flutter/material.dart';

Color  orange100 =  Colors.blue;

List<Map> food = [
  {"name": "Avocada Salad","img": "assets/image/avacodasalad.png","price": 12},
  {"name": "Fruits Salad","img": "assets/image/fruitsalad.png","price": 30},
  {"name": "Cucumber Salad","img": "assets/image/cucumbersalad.png","price": 25},
  {"name": "Mango Salad","img": "assets/image/mangoslad.png","price": 22}
];

List<Map> photo = [
  {"img": "assets/image/avacodsalad.png"},
  {"img": "assets/image/fruits.png"},
  {"img": "assets/image/cucumbersalad.png"},
  {"img": "assets/image/mangoslad.png"}
];
List<Map> car=[
  {"name": "Avocada Salad","img": "assets/image/avacodsalad.png"},
  {"name": "Fruits Salad","img": "assets/image/fruitsalad.png"},
  {"name": "Cucumber Salad","img": "assets/image/cucumbersalad.png"},
  {"name": "Mango Salad","img": "assets/image/mangoslad.png"}

];
List<Map> drop=[
  {"name": "Avocada Salad","value": "1"},
  {"name": "Fruit Salad","value": "2"},
  {"name": "Cucumber Salad","value": "3"},
  {"name": "Mango Salad","value": "4"}
];

List<Map> cartList=[

];